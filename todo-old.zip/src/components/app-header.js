import React from 'react';
import './app-header.css'

const AppHeader = () => {
    return (
        <h1 className='app-header'>Todo list</h1>
    );
};

export default AppHeader;