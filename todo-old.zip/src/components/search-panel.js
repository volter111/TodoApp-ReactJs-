import React from 'react';

const SearchPanel = () => {
    return (
        <input placeholder='search'></input>
    );
};

export default SearchPanel;